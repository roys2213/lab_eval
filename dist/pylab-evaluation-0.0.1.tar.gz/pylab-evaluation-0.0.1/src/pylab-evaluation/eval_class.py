import random
import os
from os.path import join, isdir, isfile, getsize, abspath
import sys
import json
import pyunpack
import shutil
from importlib import import_module, invalidate_caches, reload
import traceback
from cryptography.hazmat.primitives import hashes
import json
import signal, time
import subprocess


class EvalClass:

#  def __init__( self, moodle_dir, evaluation_dir, instructor_dir ):
  def __init__( self, class_dir, instructor_dir, eval_lab_class, student_db=None ):
    """ evaluates the labs 

    This class assumes the following structure:
    project_dir:
      +- lab_grades.json 
      +- moodle_dir
          +- student1-firstname__last_name
          +- student2-firstname__last_name
          +- student3-firstname__last_name
          +- student3-firstname__last_name
      +- lab_dir
        +- student1-firstname_last_name_id
        +- student2-firstname_last_name_id
        +- student3-firstname_last_name_id
        +- student3-firstname_last_name_id
      +- eval_dir
        +- student1-firstname_last_name_id.log
    """

    self.student_db = student_db
    self.class_dir = abspath( class_dir )
    self.json_lab_grade = join( self.class_dir, 'lab_grades.json' )
    self.moodle_dir = join( self.class_dir, 'moodle' )
    self.labs_dir = join( self.class_dir, 'labs' )
    self.eval_dir = join( self.class_dir, 'eval_dir' )
    

  def create_dir( self, directory, force=False ):
    """ remove existing dir and creates a clean directory """
    if isdir( directory ) is False:
      os.makedirs( directory )
    else: 
      if len(os.listdir( directory ) ) != 0:
        if force is False:
          raise ValueError( "{directory} already exists -> re-creating it. Please delete it." )
        raise ValueError( "{directory} already exists -> re-creating it: shutil.rmtree( directory )" )
#        shutil.rmtree( directory )
        os.makedirs( directory )

  def unzip_moodle( self, moodle_zip_file  ):
    """ created the moodle directory with all students submissions """
    if isfile( moodle_zip_file  ) is False:
      raise ValueError( "Unable to find {moodle_zip_file}" )
    self.create_dir( self.moodle_dir )
    pyunpack.Archive( moodle_zip_file ).extractall( self.moodle_dir )

  def lab_id_from_moodle_dir( self, dir_name ):
    if self.student_db is None :
      lab_id = dir_name
    else:
      lab_id = self.student_db.student_id_from_moodle_dir( dir_name )
    return lab_id


  def moodle_to_labs( self ):
    """ populates lab_dir from moodle_dir

    import considers the various ways a student can submit in moodle
    """
    ## Create the destination directory
    ## Note that import only works with empty destination directory because unziping th emoodle archive creates a directory which contains all student files and the files are then  moved to the expected destination.
    ## moodle.zip --> dst_dir/moodle/<all files>
    ## instead of moodle.zip --> dst_dir/<all files>
    ## We do not see this as an issue and create_dir takes this in charge. 
    ## If that were an issue we could: 
    ## - 1) identify dst_dir/moodle/ in a better way - even unzipping in /tmp. 
    ##  Currently it is identified as the unique directory which implies 
    ##  the initial destination directory is empty.
    ## - 2) see if extract does not hav eth eappropriated feature.
    ## create_dir
    self.create_dir( self.labs_dir )
    
    for dir_name in os.listdir( self.moodle_dir ):
      if isdir( join( moodle_dir, dir_name ) ) is False:
        continue
      #creating the same directory in lab_dir
      dst_dir = join( self.lab_dir, dir_name )
      os.makedirs( dst_dir )
      src_moodle_dir = join( moodle_dir, dir_name )
      moodle_file_list = os.listdir( src_moodle_dir )
      print( f"{src_moodle_dir} contains {moodle_file_list} " )
      if len( moodle_file_list ) == 1:
#        if moodle_file_list[ 0 ] is zipfile:
        src_moodle = join( src_moodle_dir, moodle_file_list [ 0 ] )
        if isfile( src_moodle ) and ( '.gzip' in src_moodle or \
                                      '.zip' in src_moodle or \
                                      '.tar' in src_moodle or \
                                      '.gz' in src_moodle or \
                                      '.rar' in src_moodle ): # a archive file gzip, tar, tar.gz, rar...
          pyunpack.Archive( src_moodle ).extractall( dst_dir )
          ## creates an additional directory
          ## moodle.zip --> dst_dir/moodle/<all files>
          ## instead of moodle.zip --> dst_dir/<all files>
          dst_file_list = os.listdir( dst_dir ) 
          unzip_dir = join( dst_dir, dst_file_list[ 0 ] ) 
          if len( dst_file_list ) == 1 and isdir( unzip_dir ):
            for file_name in os.listdir( unzip_dir ) :  
              shutil.move( join( unzip_dir, file_name ), join( dst_dir, file_name ) )
            print( f"{unzip_dir}: shutil.rmtree( unzip_dir )" )
#            shutil.rmtree( unzip_dir )
        elif isfile( src_moodle ) and ( '.py' in src_moodle or '.pdf' in src_moodle ):
          shutil.copy( src_moodle ,dst_dir )
        
        elif isdir( src_moodle ): # a directory that contains the files 
          for student_file_name in os.listdir( src_moodle ):
            shutil.copy( join( src_moodle, student_file_name ), 
                       join( dst_dir, student_file_name ) )
        else: 
          raise ValueError( f"{src_moodle} is not a file nor a directory" )
      else: # files are directly provided
        for file_name in moodle_file_list:
          if '.pdf' in file_name or '.py' in file_name:
            shutil.copy( join( src_moodle_dir, file_name ), 
                       join( dst_dir, file_name ) )

  def eval_py( self, force=False):
    if isfile( self.json_lab_grade ) is True:
      if force is True :
        raise ValueError( f"{self.json_lab_grade}: os.remove( self.json_lab_grade )" ) 
      else:
        response = input( f"Grades have already been recorded in the file "\
                          f"{self.json_lab_grade}.\n"\
                          f"To remove and re-run the evaluation type R.\n"\
                          f"Otherwise the evaluation will skip evaluation "\
                          f"aleary performed." )
        if response == 'R':
          raise ValueError( f"{self.json_lab_grade}: os.remove( self.json_lab_grade )" ) 
#          os.remove( self.json_lab_grade )

    if isdir( self.lab ) is False:
      raise ValueError( f"Cannot perform lab evaluation lab_dir "\
        f"{self.lab_dir} not found." )
    for dir_name in os.listdir( self.lab_dir ):
      lab = self.eval_lab_class( join( self.lab_dir, dir_name), \
                          self.instructor_dir, \
                          json_score_list=self.json_lab_grade, \
                          lab_id=self.lab_id_from_moodle_dir( dir_name ) )
      lab.run_eval_py( eval_dir=self.eval_dir )


  def detect_same_files( self,  file_name_list=[] ):
    """ reports identical files with same hash 
    args:
      file_name_list: contains a list of files that should be looked at. 
      By default all files are considered whic may include input files 
      present in multiple if not all directories. Such files are not subject 
      to duplicate detection.  
    """
    hash_dict = {} 
    for student_dir in os.listdir( self.lab_dir ):
      student_file_list = os.listdir( join( self.lab_dir, student_dir) )
      if file_name_list == []:
        file_name_list = student_file_list
      for file_name in student_file_list:
        if file_name not in file_name_list:
          continue
        with open( join( self.lab_dir, student_dir, file_name), 'rb' ) as f:
          digest = hashes.Hash(hashes.SHA256())
          digest.update( f.read() )
          h = digest.finalize()
          meta_data = { 'name' : student_dir, 'file' : file_name } 
          if h in hash_dict.keys():
            hash_dict[ h ].append( meta_data )
          else: 
            hash_dict[ h ] = [ meta_data ]
    print( f"hash_dict: {hash_dict}" )
    ## removing hash with no collision
    for h in list( hash_dict.keys() ):
      if len( hash_dict[ h ] ) == 1 :
        del hash_dict[ h ]
    if len( hash_dict.keys() ) == 0:
      print( "No collisions detected: all files seems different" )
    else:
      print( "Some collisions between files have been detected" )
      print( hash_dict )
      print( json.dumps( hash_dict, indent=2 ) )


   def init_from_archive( self, moodle_zip_file ):
     """ create and overwritte the project 

     This is usually the step performed upon receiving scripts from the students.
     This steps is usually followed by an manual correction of evaluation of the
     grades - typically from a report. 
     """
     if isfile( self.moodle_zip_file ) is False:
       raise ValueError( f"Unexpected {moodle_zip_file}\n Expecting file." )

     self.create_dir( self.class_dir )
     for directory in [ self.class_dir, self.moodle_dir, \
                        self.labs_dir, self.eval_dir ]:
       if isdir( directory ) is False:
         os.makedirs( directory )
     self.unzip_moodle( self.moodle_zip_file )
     self.moodle_to_labs( )
     self.detect_same_file()
     self.eval_py( self.eval_lab_class )

  def finalize( self, expected_mean=3.2/5*100 ):
    """Finalizes the grades and provides an estimation so grades have the
       specified mean value.
    
    """
    with open( self.json_score_list, 'r', encoding='utf8' ) as f:
      score_list = json.loads( f.read() )
    mean_total_score = 0
    for lab_id in list( score_list.keys() ):
      score = score_list[ lab_id ] 
      score = EvalLab.compute_total_score( score=score_list[ lab_id ] )
      score_list[ lab_id ] = score  
      mean_total_score += score[ "grade (%)" ] 
    mean_total_score  /= len( score_list.keys() )
    factor = expected_mean / mean_total_score

    for lab_id in list( score_list.keys() ):
      score = score_list[ lab_id ] 
      score[ "harmonized grade (total)" ] = factor * score[ "grade (total)" ] 
      score[ "harmonized grade (%)" ] = factor * score[ "grade (%)" ]
      score_list[ lab_id ] = score 

    with open( self.json_score_list, 'w', encoding='utf8' ) as f:
      f.write( json.dumps( score_list, indent=2 ) )



class StudentDB:
   
  def __init__( self, json_file_name ):
    """ student DB can be extracted in a json format from moodle """
    self.json_file_name = json_file_name
    if isfile( json_file_name )
      self.db = json.load( json_file_name )

 
  def search(first_name=None, last_name=None ):
    for student in self.db :
      if student[ 'firstname' ] == first_name and student[ 'lastname' ] == last_name:
        return student
    raise ValueError( f"Student with firstname {firstname} and lastname"\
                      f" {lastname} not found." )

  def student_id_from_moodle_dir( self, dir_name ):
    """ provides a unique id associated to the student given a 
        student directory assigned by moodle 
    """
    dir_name = dir_name.split( ',' )
    last_name = dir_name[ 0 ].replace( '_', ' ' )
    last_name = last_name.strip( )
    reminder = dir_name[ 1 ][ 1 : ].split( '_' )[ : -4 ]
    first_name = reminder[ 0 ]
    if len( reminder ) > 1
    for s in reminder [ 1 : ]:
      first_name += f" {s}"
    first_name.strip() 
    lab_id = self.search( first_name=first_name, last_name=last_name )[ 'user_name' ]
   return lab_id


